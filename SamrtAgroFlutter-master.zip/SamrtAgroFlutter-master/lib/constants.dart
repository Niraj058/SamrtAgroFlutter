enum AlertAction {
  cancel,
  discard,
  disagree,
  agree,
}

const String apiURL = "https://reqres.in/api/users/5";
const bool devMode = false;
const double textScaleFactor = 1.0;